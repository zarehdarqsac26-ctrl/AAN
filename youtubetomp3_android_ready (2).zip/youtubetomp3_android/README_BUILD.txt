ANDROID BUILD

This project is prepared for Buildozer/python-for-android.

1. Install Buildozer in Linux/WSL.
2. Open this folder.
3. Run: buildozer -v android debug
4. The APK will be placed under bin/.

The app declares INTERNET and includes yt-dlp + ffmpeg as requirements.
The Windows-only font paths in main.py were replaced with Kivy's Android-safe Roboto font.
